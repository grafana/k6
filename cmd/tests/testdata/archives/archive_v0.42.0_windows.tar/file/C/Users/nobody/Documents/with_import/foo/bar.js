export function Bar() {
    console.log('called Bar() from foo/bar.js');
}