export function A() {
    console.log('called A() from a.js');
}